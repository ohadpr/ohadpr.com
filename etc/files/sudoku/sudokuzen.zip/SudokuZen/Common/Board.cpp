
#include "board.h"
#include "os.h"
#include <string.h>		// memset
#include <new>			// calling 'new' on already allocated memory


CBoard::CBoard(void)
{
	ClearBoard();
}

CBoard::~CBoard(void)
{
}

void CBoard::PreCalcPaths()
{
	for (int i=0; i<BOARD_SIZE; i++)
	{
		Path	&row	= m_paths[i];
		Path	&col	= m_paths[BOARD_SIZE+i];
		Path	&box	= m_paths[BOARD_SIZE*2+i];

		uint32 sU = (i%3)*3;
		uint32 sV = (i/3)*3;

		for (int x=0; x<BOARD_SIZE; x++)
		{
			row[x].u = x;
			row[x].v = i;

			col[x].u = i;
			col[x].v = x;

			box[x].u = sU + (x%3);
			box[x].v = sV + (x/3);
		}
	}
}

void CBoard::ClearBoard()
{
	memset(m_board, 0, sizeof(m_board));
}

BoardStatusType	CBoard::GetBoardStatus()
{
	bool	foundIncompleteness = false;
	int		nineBitsOn			= 0x3fe;	//	00000011 11111110
											//	15     8 7      0

	for (int p=0; p<NUM_PATHS; p++)
	{
		Path	&path	= m_paths[p];
		int		sum		= 0;
		int		bit;

		sum = 0;

		for (int i=0; i<BOARD_SIZE; i++)
		{
			bit = 1 << GET_FIXED(m_board[path[i].v][path[i].u]);
			if (sum & nineBitsOn & bit) return BS_ERROR;
            sum |= bit;
		}
		if (sum != nineBitsOn) foundIncompleteness = true;
	}

	// the board is solved
	return foundIncompleteness ? BS_INCOMPLETE : BS_COMPLETE;
}

void CBoard::SetItem(int u, int v, uint16 val, bool isOption, bool onOff)
{
	// range check
	if (u < 0 || u >= BOARD_SIZE || v < 0 || v >= BOARD_SIZE || val > 10) return;

	// our item
	uint16&	item = m_board[v][u];

	if (!isOption)
	{
		item &= ~BOARD_ITEM_FIXED_MASK;		// remove any previously stored FIXED number
		item |= val;						// store the new value (0..10)
	}
	else
	{
		uint16 shift = BOARD_ITEM_OPTIONS_START_BIT + val - 1;
		if (onOff)	item |= (1<<shift);		// turn on
		else		item &= ~(1<<shift);	// turn off
	}
}

void CBoard::DirectSetItem(int u, int v, uint16 val)
{
	// range check
	if (u < 0 || u >= BOARD_SIZE || v < 0 || v >= BOARD_SIZE) return;

	m_board[v][u] = val;
}


uint16 CBoard::GetItem(int u, int v)
{
	// range check
	if (u < 0 || u >= BOARD_SIZE || v < 0 || v >= BOARD_SIZE) return 0xffff;

	return m_board[v][u];
}

void CBoard::FillPencilMarks()
{
	// turn on all the options
	for (int v=0; v<BOARD_SIZE; v++)
	{
		for (int u=0; u<BOARD_SIZE; u++)
		{
			uint16& b = m_board[v][u];

			if (HAS_FIXED(b))	b &= ~BOARD_ITEM_OPTIONS_MASK;	// all options OFF
			else				b |= BOARD_ITEM_OPTIONS_MASK;	// all options ON
		}
	}

	int	nineBitsOn = 0x3fe;	//	00000011 11111110
							//	15     8 7      0

	for (int p=0; p<NUM_PATHS; p++)
	{
		Path	&path	= m_paths[p];
		int		sum		= 0;

		// figure out all the numbers that are used, and create a mask out of it
		for (int i=0; i<BOARD_SIZE; i++) sum |= (1 << GET_FIXED(m_board[path[i].v][path[i].u]));

		// check (ignore first bit which can be set by '1<<0')
		if ((sum&(~1)) != nineBitsOn)
		{
			// all 'on' bits on sum must be masked out of the item's OPTIONS
			sum = (~((sum >> 1) << BOARD_ITEM_OPTIONS_START_BIT)) | ~BOARD_ITEM_OPTIONS_MASK;

			// apply it to all the items in this path
			for (int i=0; i<BOARD_SIZE; i++) m_board[path[i].v][path[i].u] &= sum;
		}
	}
}

int CBoard::ApplyRule1()
{
	int numSolved = 0;

	// go over all the board, looking for items that have only 1 option
	for (int v=0; v<9; v++)
	{
		for (int u=0; u<9; u++)
		{
			uint16	&b = m_board[v][u];

			// if this guy has a value, skip it
			if (HAS_FIXED(b)) continue;

			uint16	o = GET_OPTIONS(b);

			// find what options are on, and if only one is one, store it's index
			int		numOptions	= 0;
			uint16	optionVal	= 0;
			for (int x=0; x<BOARD_SIZE; x++)
			{
				if ((o>>x) & 1)
				{
					numOptions++;
					optionVal = x+1;
				}
			}

			// if there's 1 option -> fix this baby to this one option
			if (numOptions == 1)
			{
				b |= optionVal;
				numSolved++;
			}
		}
	}

	return numSolved;
}


int CBoard::ApplyRule2()
{
	int numSolved = 0;

	// go over all the paths
 	for (int p=0; p<NUM_PATHS; p++)
	{
		Path	&path = m_paths[p];

		struct
		{
			Point	lastCell;	// the last cell this option appeared in
			int		counter;	// how many cells had this option on
		} options[BOARD_SIZE];

		memset(&options, 0, sizeof options);

		// for each path, scan all the cells and their options. for each possible option write down that it was possible
		// and increase the 'how many times was this possible counter' for it.

		// go over this path
		for (int i=0; i<BOARD_SIZE; i++)
		{
			uint16	b = m_board[path[i].v][path[i].u];

			// if this guy doesn't have a value, great, pick up it's options
			if (NO_FIXED(b))
			{
				int cellOptions = GET_OPTIONS(b);

				// go over all the options
				for (int x=0; x<BOARD_SIZE; x++)
				{
					if ((cellOptions>>x) & 1)
					{
						options[x].lastCell = path[i];
						options[x].counter++;
					}
				}
			}
			// otherwise, we need to let the other's know that this number is taken,
			// we'll fake it by maxing out this option
			else
			{
				options[GET_FIXED(b) - 1].counter = 2;
			}
		}

		// we completed the path, now check if there are any options that appear in only 1 place
		for (int x=0; x<BOARD_SIZE; x++)
		{
			if (options[x].counter == 1)
			{
				// great, this option appeared in only 1 place, it means this cell must contain this value
				uint16& b = m_board[options[x].lastCell.v][options[x].lastCell.u];

				// remove any fixed value that may be there (when we're working on an erronous board, a single
				// cell can be found to be able to contain several FIXED values, hence a mere |= causes lots of trouble)
				b &= ~BOARD_ITEM_FIXED_MASK;
				b |= x+1;

				numSolved++;
			}
		}
	}

	return numSolved;
}

// helper function to take options-bit-mask and return a randomly-sorted array of the options
static void RandomifyOptions(uint16 options, uint8* result, uint8* numResults)
{
	uint8	num = 0;
	uint8	x;

	// find all the ON options and store in an array
	for (x=0; x<BOARD_SIZE; x++)
	{
		// is this option on ?
		if ((options >> x) & 1)	result[num++] = x+1;
	}

	// random-sort the array
	// for each position in the array, choose a random digit from the rest of the array
	for (x=0; x<num-1; x++)
	{
		uint8 src = x + 1 + (OS_RAND % (num-x-1));
		
		// switch between 'x' and 'src'
		uint8 tmp = result[x];
		result[x] = result[src];
		result[src] = tmp;
	}

    // return number of results
	*numResults = num;
}
extern void PrintBoard(CBoard& b);
void CBoard::ReducePencilMarks()
{
	// Block and Column / Row Interactions
	// http://www.simes.clara.co.uk/programs/sudokutechnique3.htm

	// scan all blocks
	for (uint32 i=0; i<BOARD_SIZE; i++)
	{
		Path &path = m_paths[BOARD_SIZE*2+i];	// the path for this box

		// for each block, go over each optional number (1..9)
		for (int x=1; x<=BOARD_SIZE; x++)
		{
			int		counter		= 0;
			Point	found;

			// find all the places that x is an option at
			for (uint32 j=0; j<BOARD_SIZE; j++)
			{
				uint16 val = m_board[ path[j].v ][ path[j].u ];

				// is this option already set as a fixed value somewhere in this block ?
				if (GET_FIXED(val) == x)
				{
					counter = 0;
					break;
				}

				if (GET_OPTION(val,x))
				{
					if		(counter == 0)	found = path[j];	// store location of first occurance of option
					else if (counter == 1)						// second apperance, find the axis
					{
						if		(path[j].u == found.u) found.v = -1;	// same U, vertical axis, wipe out V value
						else if (path[j].v == found.v) found.u = -1;	// same V, horizontal axis, wipe out U value
						else { counter = 0; break; }					// not an axis, stop checking this option (counter=0)
					}
					else												// make sure we are maintaining the axis
					{
						if ((found.u == -1 && found.v != path[j].v) ||
							(found.v == -1 && found.u != path[j].u))
						{
							// not an axis, stop checking this option (counter=0)
							counter = 0;
							break;
						}
					}

					counter++;
				}
			}

			// if we didn't get an axis, get out of here
			if (counter == 0 || counter > 3) continue;

			uint16	removeOptionMask = ~(1<<(BOARD_ITEM_OPTIONS_START_BIT+x-1));

			// great, we have an axis, eliminate this option from this axis on other blocks
			if (found.u == -1 || counter == 1)
			{
				// horizonal axis
				for (uint32 j=0; j<BOARD_SIZE; j++)
				{
					if (j < path[0].u || j > path[BOARD_SQRT_SIZE-1].u)
					{
						m_board[found.v][j] &= removeOptionMask;
					}
				}
			}

			if (found.v == -1 || counter == 1)
			{
				// vertical axis
				for (uint32 j=0; j<BOARD_SIZE; j++)
				{
					if (j < path[0].v || j > path[BOARD_SIZE-1].v)
					{
						m_board[j][found.u] &= removeOptionMask;
					}
				}
			}
		}
	}
}

/*static int recurse = 0;
static int mx = 0;
#include <stdio.h>
class CMoyshe
{
	public:
	CMoyshe() { recurse++;}// if (recurse > mx) {mx = recurse; printf("%d\n",mx);}
	~CMoyshe() { recurse--; }
};*/

/*#include <PalmOS.h>
#include <StringMgr.h>

		char str[123];
		int kkk = 0;*/

extern "C++" int counter;
int counter;
#include <stdio.h>

SolutionType CBoard::Solve(uint8 determineIfMultiple)
{
	counter++;
/*	CMoyshe	moyshe;
	if (recurse == 1) kkk=0;
	kkk++;

		StrPrintF(str, "solver depth=%d/%d     ", recurse, kkk);
		WinDrawChars(str, StrLen(str), 0, 80);*/
	
	
	{
		uint8	numSolved	= 1;	// bypass first test
		
		//if (recurse > 34) return SOLUTION_SINGLE;	
	
		for (;;)
		{
			// check board status
			BoardStatusType	boardStatus = GetBoardStatus();
	
			if		(boardStatus == BS_COMPLETE)	return SOLUTION_SINGLE;	// we're done
			else if	(boardStatus == BS_ERROR)		return SOLUTION_NONE;	// the board leads to an error
			else if (numSolved == 0)				break;					// not done but can't get anything else, out of this loop
	
			// fill-in trivial pencil marks
			FillPencilMarks();

			ReducePencilMarks();
	
			// apply rules and attempt to improve our status
			numSolved	=	ApplyRule1();
			numSolved	+=	ApplyRule2();
		}
	}

	// trial-and-error
	CSolveStack* s = AllocStack();

	// find a cell that doesn't have a fixed value
	for (s->x=0; s->x<BOARD_SIZE*BOARD_SIZE; s->x++)
	{
		s->u = m_randomScan[s->x].u;
		s->v = m_randomScan[s->x].v;
		if (NO_FIXED(m_board[s->v][s->u])) break;
	}

	// [v][u] doesn't have a fixed value

	// random sort the options
	RandomifyOptions(GET_OPTIONS(m_board[s->v][s->u]), s->options, &s->numOptions);

	// go over it's options and try them each at a time
	for (s->x=0; s->x<s->numOptions; s->x++)
	{
		// create a new board for the experiment
		s->tempBoard = *this;

		// set the value we're going to test
		s->tempBoard.SetItem(s->u, s->v, s->options[s->x]);

		// now try to recursively solve
		s->sol = s->tempBoard.Solve(determineIfMultiple);

		// see if we're going to send back the result
		if ((s->sol == SOLUTION_MULTIPLE) ||							// we have multiple results, send them back
			(s->sol == SOLUTION_SINGLE && !determineIfMultiple) ||		// we have one result, and we were'nt asked for more than that
			(s->sol == SOLUTION_SINGLE && determineIfMultiple && s->foundSol != -1))	// we got one result, but already have one stored
																						// and we're looking for more than one, great
		{
			*this = s->tempBoard;
			SolutionType retVal = (s->sol == SOLUTION_MULTIPLE || s->foundSol != -1) ? SOLUTION_MULTIPLE : SOLUTION_SINGLE;
			FreeStack();
			return retVal;
		}

		// is this the first solution, and we're looking for multiple ?
		if (s->sol == SOLUTION_SINGLE && determineIfMultiple && s->foundSol == -1)
		{
            // yes, mark the fact that we found a singlue solution
			s->foundSol = s->x;
		}

		// move on
	}

	// if we're here, we either have no result, or we're looking for multiple results and found just one
	if (s->foundSol == -1)
	{
		FreeStack();
		return SOLUTION_NONE;
	}

	// we found just one solution, reconstruct the solution and send it back
	SetItem(s->u, s->v, s->options[s->foundSol]);
	FreeStack();
	Solve();

	return SOLUTION_SINGLE;
}

SolutionType CBoard::IsSolveable()
{
	CBoard	temp = *this;
	return temp.Solve(1);
}

void CBoard::Generate(uint16 seed, uint8 targetVisible)
{
//on 	WinDrawChars("clearing", 8, 0, 0);
	
	ClearBoard();

	// set a random seed
	OS_SRAND(seed);

//	WinDrawChars("solving", 7, 0, 10);

	// 'solve' this board (fill it up)
	Solve();

//	WinDrawChars("solved", 6, 0, 20);	

	//
	// remove cells
	//
	CBoard	tempBoard;
//	int	counter=0;

	for (;;)
	{
		// choose 'targetVisibile' random positions and reveal them
		for (int x=0; x<targetVisible; x++)
		{
			int u, v;

			do
			{
				u = OS_RAND % BOARD_SIZE;
				v = OS_RAND % BOARD_SIZE;
			} while (HAS_FIXED(tempBoard.m_board[v][u]));
            
            tempBoard.m_board[v][u] = m_board[v][u];
		}

		// is this sovealbe with a single-solution ?
		CBoard	tempBoard2 = tempBoard;

		if (tempBoard2.Solve(1) == SOLUTION_SINGLE) break;

		tempBoard.ClearBoard();	
	/*	
		counter++;
		
		char str[123];
		StrPrintF(str, "attempt %d", counter);
		WinDrawChars(str, StrLen(str), 0, 30);*/
	}

	// copy result
	*this = tempBoard;	

	// done
}


bool CBoard::GetHint(int &u, int &v, uint16& value)
{
	CBoard	tempBoard = *this;

	if (tempBoard.Solve() == SOLUTION_NONE) return false;
	
	// how many empty cells do we have ?
	int	numEmptyCells = 0;
	
	for (int y=0; y<BOARD_SIZE; y++)
		for (int x=0; x<BOARD_SIZE; x++)
			if (GET_FIXED(m_board[y][x]) == 0)
				numEmptyCells++;
	
	int	ourCell = OS_RAND % numEmptyCells;
	numEmptyCells = 0;
	
	for (int y=0; y<BOARD_SIZE; y++)
	{
		for (int x=0; x<BOARD_SIZE; x++)
		{
			if (GET_FIXED(m_board[y][x]) == 0 && numEmptyCells++ == ourCell)
			{
				u = x;
				v = y;
				value = GET_FIXED( tempBoard.GetItem(x,y) );			
				return true;
			}
		}
	}
	
	// we shouldn't get here, but still
	return false;
}


// memory manager
#define NUM_STACKS	(BOARD_SIZE*BOARD_SIZE+5)	// maximum depth of board-solving recursion

int		CBoard::m_memPos	= 0;
char*	CBoard::m_mem		= 0;
Path	CBoard::m_paths[NUM_PATHS];
Point	CBoard::m_randomScan[BOARD_SIZE*BOARD_SIZE];

// one time allocate
void CBoard::InitMem()
{
	m_memPos = 0;
	m_mem = new char[sizeof(CSolveStack)*NUM_STACKS];

	PreCalcPaths();

	// create a random-scan of the board
	for (int x=0; x<BOARD_SIZE; x++)
		for (int y=0; y<BOARD_SIZE; y++)
		{
			m_randomScan[x+y*BOARD_SIZE].u = x;
			m_randomScan[x+y*BOARD_SIZE].v = y;
		}
	
	OS_SRAND(1234);	
	// random-sort the array
	// for each position in the array, choose a random digit from the rest of the array
	for (int x=0; x<BOARD_SIZE*BOARD_SIZE-1; x++)
	{
		int src = x + 1 + (OS_RAND % (BOARD_SIZE*BOARD_SIZE-x-1));
		
		// switch between 'x' and 'src'
		Point tmp = m_randomScan[x];
		m_randomScan[x] = m_randomScan[src];
		m_randomScan[src] = tmp;
	}
}

// one time de-allocate
void CBoard::KillMem()
{
	if (m_mem) delete m_mem;
}

CSolveStack *CBoard::AllocStack()
{
	if (m_memPos >= NUM_STACKS) return 0;

	char *ptr = m_mem + sizeof(CSolveStack)*(m_memPos++);

	// run constructor
	CSolveStack* ret = new(ptr) CSolveStack;

	return ret;
}

void CBoard::FreeStack()
{
	if (m_memPos == 0) return;
	
	char		*ptr	= m_mem + sizeof(CSolveStack)*(m_memPos--);
	CSolveStack	*board	= (CSolveStack*)ptr;

	// run destructor
	board->~CSolveStack();
}