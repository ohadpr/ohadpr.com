
#ifndef COMMON_H_INC
#define COMMON_H_INC

typedef unsigned char	byte;
typedef unsigned long	mword;

typedef   signed char	int8;
typedef unsigned char	uint8;
typedef   signed short	int16;
typedef unsigned short	uint16;
typedef   signed long	int32;
typedef unsigned long	uint32;

#endif // COMMON_H_INC