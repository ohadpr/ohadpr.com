// this file defines OS-specific macros

// win32

#include <stdlib.h>
#define OS_RAND			rand()
#define OS_SRAND(x)		srand(x)
