//
// Ending.h
//
// Ending header file
//

#ifndef __Ending_H__
#define __Ending_H__

// includes
#include "base.h"

#include "vector.h"

// defs

// structs

// vars

// funcs/classes
class Ending
{
public:
	Ending();
	~Ending();
	

	void Render();


private:

	// textures
};


#endif //__Ending_H__