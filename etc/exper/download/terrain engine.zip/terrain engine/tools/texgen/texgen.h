#ifndef TEXGEN_H
#define TEXGEN_H


// defs
typedef unsigned  char	byte;
typedef unsigned  short	word;
typedef unsigned  long  dword;
typedef signed    char  sbyte;
typedef signed    short sword;
typedef	signed    long  sdword;


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <windows.h>


#include "ijl.h"

#include "my_jpg_interface.h"




#endif //TEXGEN_H