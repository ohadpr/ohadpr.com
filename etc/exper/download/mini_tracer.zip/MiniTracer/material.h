#ifndef _MATERIAL_H
#define _MATERIAL_H

#include "vector.h"


class Material
{
public:

	Color	diffuseColor,
			specularColor;

	double	specularHighlight,	// size of highlight
			specularShininess;	// strength of highlight
};

#endif //_MATERIAL_H