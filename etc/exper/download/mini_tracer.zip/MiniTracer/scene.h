#ifndef _SCENE_H
#define _SCENE_H

#include "base.h"
#include "vector.h"
#include "sphere.h"
#include "omni.h"


class Scene
{
public:
	Scene();
	~Scene();
	
	void InitData();
	void RenderToFile();
	void RenderToWindow(void *hInstance);
	void RenderToScreenSaver(void *hWnd);

	dword	 nSpheres;

private:

	// world data
//	dword	 nSpheres;
	Sphere	*pSpheres;

	dword	 nOmnis;
	Omni	*pOmnis;

	Color	 bgColor;		// background color
	Color	 ambientColor;	// ambient color

	// camera
	Vector	 camSrc, camDst;
	double	 camFov;
	double	 nearZ, farZ;	// clipping planes

	// render buffer
	dword	 xRes, yRes;
	dword	*pRenderBuf;

	dword	 numRays;

	Color	TraceRay(Vector &O, Vector &D, Sphere *pOrigSphere);
};

#endif //_SCENE_H