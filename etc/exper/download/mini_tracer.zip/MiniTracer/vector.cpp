#include "base.h"
#include "vector.h"
#include <math.h>

Vector::Vector()
{
	x = y = z = 0;
}

Vector::Vector(double _x, double _y, double _z)
{
	x = _x;
	y = _y;
	z = _z;
}

void Vector::Set(double _x, double _y, double _z)
{
	x = _x;
	y = _y;
	z = _z;
}

void Vector::SelfNorm()
{
	double l;

	l = sqrt(x*x+y*y+z*z);
	x /= l;
	y /= l;
	z /= l;
}

Vector Vector::Norm()
{
	double	l;
	Vector	v;

	l = sqrt(x*x+y*y+z*z);
	v.x = x/l;
	v.y = y/l;
	v.z = z/l;

	return v;
}

Vector Vector::operator-(Vector &v)
{
	return Vector(x-v.x, y-v.y, z-v.z);
}

Vector Vector::operator+(Vector &v)
{
	return Vector(x+v.x, y+v.y, z+v.z);
}

void Vector::operator+=(Vector &v)
{
	*this = *this+v; 
};

Vector Vector::operator*(double f)
{
	return Vector(x*f, y*f, z*f);
}

Vector Vector::operator*(Vector &v)
{
	return Vector(x*v.x, y*v.y, z*v.z);
}

