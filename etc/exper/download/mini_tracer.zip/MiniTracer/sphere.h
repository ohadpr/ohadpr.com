#ifndef _SPHERE_H
#define _SPHERE_H

#include "vector.h"


class Sphere
{
public:
	void Set(double _x, double _y, double _z, double _r, double _rf);
	bool IntersectRay(Vector &O, Vector &D, double &t);

	Vector	Pos;	// position
	double	r;		// radius
	Color	diffuseColor;	// sphere color

	double	reflectionFact;	// reflection factor, 0=no reflection, 1=completly reflecting
};

#endif //_SPHERE_H