#ifndef _BASE_H
#define _BASE_H


typedef unsigned char byte;
typedef signed char sbyte;
typedef unsigned short word;
typedef signed short sword;
typedef unsigned long dword;
typedef signed long sdword;


#endif // _BASE_H
