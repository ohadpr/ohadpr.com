#ifndef _OMNI_H
#define _OMNI_H

#include "vector.h"


class Omni
{
public:

	Vector	pos;	// Position

	Color	diffuseColor;
};

#endif //_OMNI_H