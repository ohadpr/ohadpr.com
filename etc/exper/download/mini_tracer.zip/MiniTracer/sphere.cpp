
#include "base.h"
#include "sphere.h"
#include <math.h>

void Sphere::Set(double _x, double _y, double _z, double _r, double _rf)
{
	Pos.Set(_x,_y,_z);
	r = _r;
	reflectionFact = _rf;
}

bool Sphere::IntersectRay(Vector &O, Vector &D, double &t)
{
	Vector	U;	// Origin minus sphere center
	double	a, b, c, d;	// quadric equation parameters

	U = O - Pos;

	a = DotProd(D, D);
	b = 2*DotProd(U,D);
	c = DotProd(U,U)-r*r;

	d = b*b -4*a*c;

	if (d <= 0) {
		// no hit
		return false;
	} else {
		// we have a hit
		double tt[2];

		d = sqrt(d);
		a = 1.0/(2*a);

		tt[0] = (-b+d)*a;
		tt[1] = (-b-d)*a;

		if ((tt[0] < 0 && tt[1] > 0) ||
			(tt[1] < 0 && tt[0] > 0)) {
			// we're inside
			return false;
		}

		dword smaller = tt[1] < tt[0];

		if (tt[smaller] > 0) {
			t = tt[smaller];
		} else {
			t = tt[!smaller];
		}

		return true;
	}
}