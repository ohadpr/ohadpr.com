#ifndef _VECTOR_H
#define _VECTOR_H

class Vector
{
public:
	Vector();
	Vector(double _x, double _y, double _z);

	void Set(double _x, double _y, double _z);	// Set Parameters
	void SelfNorm();							// Normalize current data

	Vector Norm();								// return a normalized vector

	Vector operator-(Vector &v);				// return subtraction with another vector
	Vector operator+(Vector &v);				// return addition with another vector
	Vector operator*(double f);					// return scaling by a double value
	Vector operator*(Vector &v);				// return multiplication with another vector (dot product)
	void operator+=(Vector &v);					// adds another vector to 'this'

	union {
		struct {
			double	x, y, z;
		};
		struct {
			double	r, g, b;
		};
	};
};


inline double DotProd(Vector &a, Vector &b) 
{
	return a.x*b.x + a.y*b.y + a.z*b.z;
}


typedef Vector Color;


#endif //_VECTOR_H