
// includes
#include <windows.h>
#include <process.h>
#include <time.h>
#include <stdio.h>
#include <scrnsave.h>
#include "..\scene.h"
#include "resource.h"

static int nSpheres;
FILE *f;


BOOL WINAPI RegisterDialogClasses (HANDLE hInst)
{
    return 1;
}

BOOL CALLBACK ScreenSaverConfigureDialog(HWND hDlg, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	switch (Msg) {
	case WM_INITDIALOG:
		if ((f = fopen("c:/minitracer.cfg", "rt"))) {
			fscanf(f, "NumSpheres=%d", &nSpheres);
			fclose(f);
		} else {
			// default value
			nSpheres = 60;
		}
		SetDlgItemInt(hDlg, IDC_NSPHERES, nSpheres, true);
		return true;
		break;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK) {
			nSpheres = GetDlgItemInt(hDlg, IDC_NSPHERES, &nSpheres, true);
			f = fopen("c:/minitracer.cfg", "wt");
			fprintf(f, "NumSpheres=%d", nSpheres);
			fclose(f);
			EndDialog(hDlg, 0);
		}
		return true;
		break;
	}
    return false;
}

static HWND	hWnd;
void __cdecl tracer(void *pVar);


LONG CALLBACK ScreenSaverProc(HWND _hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{	
	switch (msg) {
	case WM_CREATE:
		hWnd = _hWnd;
		_beginthread(tracer, 1024*16, 0);
		break;

    case WM_DESTROY:            /* message: window being destroyed */
		//stop app
		break;
    }

    return DefScreenSaverProc(_hWnd, msg, wParam, lParam); 
}


void __cdecl tracer(void *pVar)
{
	if ((f = fopen("c:/minitracer.cfg", "rt"))) {
		fscanf(f, "NumSpheres=%d", &nSpheres);
		fclose(f);
	} else {
		// default
		nSpheres = 60;
	}

	for(;;) {

		Scene	*pScene;
		pScene = new Scene;

		pScene->nSpheres = nSpheres;
		pScene->InitData();
		pScene->RenderToScreenSaver(hWnd);

		delete pScene;
	}
}