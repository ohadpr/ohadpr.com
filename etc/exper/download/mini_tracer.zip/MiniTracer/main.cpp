// minitracer

#include <windows.h>
#include "scene.h"

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.

	Scene	myScene;

	myScene.nSpheres = 60;
	myScene.InitData();

	//myScene.RenderToFile();
	myScene.RenderToWindow(hInstance);


	return 0;
}



