
#include "scene.h"
#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>


Scene::Scene()
{
	pSpheres = 0;
	nSpheres = 0;
	pRenderBuf = 0;

	numRays = 0;
}

#define SAFE_DELETE(x) \
	if (x) { delete x; x = 0; }

Scene::~Scene()
{
	SAFE_DELETE(pRenderBuf);
	SAFE_DELETE(pSpheres);
	SAFE_DELETE(pOmnis);
}

void Scene::InitData()
{
	srand(time(0));

	// initialize data
//	nSpheres = 80;
	pSpheres = new Sphere[nSpheres];
	for (dword i=0; i<nSpheres; i++) {
		pSpheres[i].Pos.Set((rand()%100)-50, (rand()%100)-50, 40+(rand()%100));
		pSpheres[i].r = 2+(rand()%19);
		pSpheres[i].diffuseColor.Set((rand()%100)/100.0, (rand()%100)/100.0, (rand()%100)/100.0);
		pSpheres[i].reflectionFact = 0.6f;
	}

/*	nSpheres = 100;
	pSpheres = new Sphere[nSpheres];
	for (dword i=0; i<10; i++) {
		for (dword j=0; j<10; j++) {
			pSpheres[i*10+j].Pos.Set((i-5.0)*8, (j-5.0)*8, 40);
			pSpheres[i*10+j].r = 3;
			pSpheres[i*10+j].diffuseColor.Set((rand()%100)/100.0, (rand()%100)/100.0, (rand()%100)/100.0);
			pSpheres[i*10+j].reflectionFact = 0.6f;
		}
	}*/

/*	pSpheres[0].Pos.Set(0,-10000,0);
	pSpheres[0].r = 9995;
	pSpheres[0].reflectionFact = 0.1f;*/

/*	nSpheres = 20;
	pSpheres = new Sphere[nSpheres];
	for (dword i=0; i<nSpheres; i++) {
		pSpheres[i].Pos.Set(30*cosf(i*2*3.141f/nSpheres), 30*sinf(i*2*3.141f/nSpheres), 60);
		pSpheres[i].r = 5;
		pSpheres[i].diffuseColor.Set((rand()%100)/100, (rand()%100)/100, (rand()%100)/100);
		pSpheres[i].reflectionFact = 0.6f;
	}*/

	nOmnis = 1;
	pOmnis = new Omni[nOmnis];
	pOmnis->pos.Set((rand()%100)-50,(rand()%100)-50,rand()%40);
	pOmnis->diffuseColor.Set(1,1,1);

	
	bgColor.Set(0,0,0);
	ambientColor.Set(0,0,0);


	// set camera data
	camSrc.Set(0,0,0);
	camDst.Set(0,0,1);
	camFov = 90;
	nearZ = 0.1f;
	farZ = FLT_MAX;
	
	xRes = 640;
	yRes = 480;
}


Color Scene::TraceRay(Vector &O, Vector &D, Sphere *pOrigSphere = 0)
{
	static dword depth = 0;
	double	 intT = farZ;		// intersection t
	Sphere	*pIntSphere = 0;	// intersection sphere

	depth++;

	numRays++;

	// go over all of our spheres
	for (dword i=0; i<nSpheres; i++) {
		double t;
		if (pSpheres[i].IntersectRay(O, D, t)) {
			// we have intersection with a sphere
			if (t < intT && t > nearZ && pSpheres+i != pOrigSphere) {
				// new 'best' intersection
				intT = t;
				pIntSphere = pSpheres+i;
			}
		}
	}

	// do we have an intersection with a sphere ?
	if (pIntSphere) {

		Vector	U,	// intersection point;
				N;	// normal at intersection point
		Color	col = ambientColor;


		U = O + (D*intT);	// calculate intersection point
		N = (U - pIntSphere->Pos).Norm();	// calculate normal at intersection point

		// go over light sources

		for (dword i=0; i<nOmnis; i++) {
			Vector	L;	// vector from intersection point to light
			double	dotProd;

			L = (pOmnis[i].pos - U).Norm();

/*			bool isShaded = false;
			// check if light from this source hits this sphere
			for (dword j=0; j<nSpheres; j++) {
				double t;
				if (pSpheres+j != pIntSphere && pSpheres[j].IntersectRay(pOmnis[i].pos, L, t)) {
					if (t < DotProd(L,L)-pSpheres[j].r*pSpheres[j].r) {
						// intersection
						isShaded = true;
						break;
					}
				}
			}			

			if (isShaded) {
				break;
			}*/


			dotProd = DotProd(L, N);

			if (dotProd > 0) {
				// we have light

				// get color of sphere at this point

				col += pIntSphere->diffuseColor*(pOmnis[i].diffuseColor*dotProd);

				// calculate specular highlight
				Vector	RL,	// reflected light
						IL,	// intersection point to light
						IE;	// vector from intersection point to eye
				IL = pOmnis[i].pos-U;
				RL = (IL - N*DotProd(IL*2,N)).Norm();
				IE = (U-O).Norm();

				double dp;
				if ((dp = DotProd(RL,IE)) > 0) {
					col += pOmnis[i].diffuseColor*pow(dp,9)*0.8;
				}
			}
		}

		// now that we've computed the color at this pixel, check for reflection
		if (pIntSphere->reflectionFact > 0 && depth < 100) {
			// yes
			
			//calculate reflection vector
			Vector R;

			R = (U - N*DotProd(U*2,N)).Norm();

			// shoot ray
			Color	secondRayCol;

			secondRayCol = TraceRay(U, R, pIntSphere) * pIntSphere->reflectionFact;

			depth--;

			return col + secondRayCol;
		}

		depth--;

		return col;
	} else {
		depth--;
		// no intersection, null color

		// is this a first ray ? ir so return background color, otherwise black
		return Color(0.3,0.3,0.3);
	}
}



void Scene::RenderToFile()
{
	pRenderBuf = new dword[xRes*yRes];


	// go over pixels
	for (dword x=0; x<xRes; x++) {
		for (dword y=0; y<yRes; y++) {
			// calculate ray direction
			Vector D;

			double tanFov;
			tanFov = tan(camFov*0.5f*3.141592687f/180);

			D.Set(	(x-xRes*0.5f)*tanFov/(xRes*0.5f),
					(yRes*0.5f-y)*tanFov*yRes/xRes/(yRes*0.5f),
					1);
			D.SelfNorm();

			Color col;

			col = TraceRay(camSrc, D);

			// clip color
			if (col.r > 1) { col.r = 1; }
			if (col.g > 1) { col.g = 1; }
			if (col.b > 1) { col.b = 1; }

			pRenderBuf[x+y*xRes] = ((dword)(col.r*255)<<16) + ((dword)(col.g*255)<<8) + (dword)(col.b*255);
		}
	}

	// save file
	FILE *f;
	f = fopen("1.raw", "wb");
	for (dword y=0; y<yRes; y++) {
		for (dword x=0; x<xRes; x++) {
			byte rgb[3];
			rgb[0] = (byte)((pRenderBuf[x+y*xRes] & 0xff0000)>>16);
			rgb[1] = (byte)((pRenderBuf[x+y*xRes] & 0x00ff00)>>8);
			rgb[2] = (byte)((pRenderBuf[x+y*xRes] & 0x0000ff));
			fwrite(rgb, 3, 1, f);
		}
	}
	fclose(f);
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) 
	{
		case WM_DESTROY:
			PostQuitMessage(0);
			break;

		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

void Scene::RenderToWindow(void *hInstance)
{
	char szWindowClass[] = "MINITRACER_CLASS";
	HWND	hWnd;

	// register window calss
	WNDCLASSEX wcex;

	wcex.cbSize			= sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= (HINSTANCE)hInstance;
	wcex.hIcon			= 0;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= 0;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= 0;

	RegisterClassEx(&wcex);

	// Perform application initialization:
	hWnd = CreateWindow(szWindowClass, "Mini-Tracer", WS_BORDER + WS_CAPTION + WS_SYSMENU,
						CW_USEDEFAULT, CW_USEDEFAULT, xRes+4, yRes+20, 0, 0, (HINSTANCE)hInstance, 0);

	ShowWindow(hWnd, SW_SHOW);
	UpdateWindow(hWnd);

	// initialize stuff
	BITMAPINFO	bmpInfo;
	bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmpInfo.bmiHeader.biWidth = xRes;
	bmpInfo.bmiHeader.biHeight = -(sword)yRes;
	bmpInfo.bmiHeader.biPlanes = 1;
	bmpInfo.bmiHeader.biBitCount = 32;
	bmpInfo.bmiHeader.biCompression = BI_RGB;
	bmpInfo.bmiHeader.biSizeImage = 0;
	bmpInfo.bmiHeader.biXPelsPerMeter = 1;
	bmpInfo.bmiHeader.biYPelsPerMeter = 1;
	bmpInfo.bmiHeader.biClrUsed = 0;
	bmpInfo.bmiHeader.biClrImportant = 0;


	pRenderBuf = new dword[xRes*yRes];


	// Main message loop:
	for (dword y=0; y<yRes; y++) {
		MSG msg;
		while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
			if (msg.message == WM_QUIT) {
				return;
			}	

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	
		// raytrace
		for (dword x=0; x<xRes; x++) {
			Vector D;

/*			double tanFov;
			tanFov = tanf(camFov*0.5f*3.141f/180);

			D.Set(	(x-(xRes/2))*sin(camFov*0.5f*3.141f/180)/(xRes/2), 
					((yRes/2)-y)*sin(camFov*0.5f*3.141f/180)*((double)yRes/xRes)/(yRes/2),
					1);
			D.Norm();*/
			double tanFov;
			tanFov = tan(camFov*0.5*3.141592687/180);

			D.Set(	(x-xRes*0.5)*tanFov/(xRes*0.5),
					(yRes*0.5-y)*tanFov*yRes/xRes/(yRes*0.5),
					1);
			D.SelfNorm();


			Color col;

			col = TraceRay(camSrc, D);

			// clip color
			if (col.r > 1) { col.r = 1; }
			if (col.g > 1) { col.g = 1; }
			if (col.b > 1) { col.b = 1; }

			pRenderBuf[x+y*xRes] = ((dword)(col.r*255)<<16) + ((dword)(col.g*255)<<8) + (dword)(col.b*255);
		}

		if (y % 10 == 0 || y==yRes-1) {
			// flip
			HDC	dc;

			dc = GetDC(hWnd);

			StretchDIBits(	dc, 
							0, 0, xRes, yRes, 
							0, 0, xRes, yRes, 
							pRenderBuf, &bmpInfo,
							DIB_RGB_COLORS,
							SRCCOPY);

			ReleaseDC(hWnd, dc);
		}
	}

	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0)) {
		if (msg.message == WM_PAINT) {
			// flip
			HDC	dc;

			dc = GetDC(hWnd);

			StretchDIBits(	dc, 
							0, 0, xRes, yRes, 
							0, 0, xRes, yRes, 
							pRenderBuf, &bmpInfo,
							DIB_RGB_COLORS,
							SRCCOPY);

			ReleaseDC(hWnd, dc);
		}

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}



void Scene::RenderToScreenSaver(void *hWnd)
{
	RECT		desktopRect;
	GetWindowRect((HWND)hWnd, &desktopRect);

	xRes = desktopRect.right - desktopRect.left;
	yRes = desktopRect.bottom - desktopRect.top;


	// initialize stuff
	BITMAPINFO	bmpInfo;
	bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmpInfo.bmiHeader.biWidth = xRes;
	bmpInfo.bmiHeader.biHeight = -(sword)1;
	bmpInfo.bmiHeader.biPlanes = 1;
	bmpInfo.bmiHeader.biBitCount = 32;
	bmpInfo.bmiHeader.biCompression = BI_RGB;
	bmpInfo.bmiHeader.biSizeImage = 0;
	bmpInfo.bmiHeader.biXPelsPerMeter = 1;
	bmpInfo.bmiHeader.biYPelsPerMeter = 1;
	bmpInfo.bmiHeader.biClrUsed = 0;
	bmpInfo.bmiHeader.biClrImportant = 0;



	pRenderBuf = new dword[xRes];

	HDC	dc;
	dc = GetDC((HWND)hWnd);

	char str[128];

	sprintf(str, "A Recursive Sphere Raytracer, by ohad");

	// draw some text
	TextOut(dc, 5, desktopRect.bottom-18, str, strlen(str));


	// Main message loop:
	for (dword y=0; y<yRes; y++) {
		// raytrace
		for (dword x=0; x<xRes; x++) {
			double tanFov;
			tanFov = tan(camFov*0.5*3.141592687/180);

			Vector D;
			D.Set(	(x-xRes*0.5)*tanFov/(xRes*0.5),
					(yRes*0.5-y)*tanFov*yRes/xRes/(yRes*0.5),
					1);
			D.SelfNorm();


			Color col;
			col = TraceRay(camSrc, D);

			// clip color
			if (col.r > 1) { col.r = 1; }
			if (col.g > 1) { col.g = 1; }
			if (col.b > 1) { col.b = 1; }

			pRenderBuf[x] = ((dword)(col.r*255)<<16) + ((dword)(col.g*255)<<8) + (dword)(col.b*255);
		}

		StretchDIBits(	dc, 
						0, y, xRes, 1, 
						0, 0, xRes, 1, 
						pRenderBuf, &bmpInfo,
						DIB_RGB_COLORS,
						SRCCOPY);

		sprintf(str, "A Recursive Sphere Raytracer, by ohad, %d rays fired", numRays);

		/*if (y > yRes-20)*/ {
			TextOut(dc, 5, desktopRect.bottom-18, str, strlen(str));
		}
	}

	ReleaseDC((HWND)hWnd, dc);
}

