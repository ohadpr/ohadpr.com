#ifndef _MAIN_H
#define _MAIN_H

// includes
#include <windows.h>
#include <process.h>
#include <time.h>
#include <stdio.h>


void start_app(HWND _hWnd);
void stop_app();


// defines
typedef unsigned char	byte;
typedef signed char		sbyte;
typedef unsigned short	word;
typedef signed short	sword;
typedef unsigned long	dword;
typedef signed long		sdword;

#endif //_MAIN_H