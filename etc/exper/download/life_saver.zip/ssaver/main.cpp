

#include "main.h"
#include <scrnsave.h>


BOOL WINAPI RegisterDialogClasses (HANDLE hInst)
{
    return 1;
}

BOOL CALLBACK ScreenSaverConfigureDialog(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
    return TRUE;
}


LONG CALLBACK ScreenSaverProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg) {
	case WM_CREATE:
		start_app(hWnd);
		break;

    case WM_DESTROY:            /* message: window being destroyed */
		stop_app();

    }  
    
    return DefScreenSaverProc(hWnd, msg, wParam, lParam); 
}