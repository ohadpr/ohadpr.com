// life implementation for a nice screen-saver

#include "main.h"

// defines
#define LIFE_WIDTH		160
#define LIFE_HEIGHT		120
#define LIFE_SIZE		(LIFE_WIDTH*LIFE_HEIGHT)

#define TARGET_FPS		25	// target frames-per-second


// variables
static HANDLE		 doFrame;
static MMRESULT		 TimerID = 0;
static HWND			 hWnd;
static byte			*pBoards[2];
static dword		 nCurBoard = 0;
static dword		 frameNum = 0;


// forward
void __cdecl life_app(void *pVar);
void life_frame();
void InitTimer();
void DeInitTimer();



// stuff

void start_app(HWND _hWnd)
{
	// initialize life
	pBoards[0] = new byte[LIFE_SIZE];
	pBoards[1] = new byte[LIFE_SIZE];

	memset(pBoards[0], 0, LIFE_SIZE);
	memset(pBoards[1], 0, LIFE_SIZE);

	srand(time(0));

	for (dword u=0; u<LIFE_WIDTH-1; u++) {
		for (dword v=0; v<LIFE_HEIGHT-1; v++) {
			if (rand() > 26384) {
				pBoards[0][u+v*LIFE_WIDTH] = 1;
			}
		}
	}

/*	pBoards[0][160*5+11] = 1;
	pBoards[0][160*6+10] = 1;
	pBoards[0][160*7+10] = 1;
	pBoards[0][160*7+11] = 1;
	pBoards[0][160*7+12] = 1;
	
	pBoards[0][160*16+10] = 1;
	pBoards[0][160*16+11] = 1;
	pBoards[0][160*16+12] = 1;

	pBoards[0][160*23+30] = 1;
	pBoards[0][160*23+31] = 1;
	pBoards[0][160*24+30] = 1;
	pBoards[0][160*24+31] = 1;*/


	// initialize
	hWnd = _hWnd;

	// create doFrame event
	doFrame = CreateEvent(0,0,0,0);

	_beginthread(life_app, 16*1024, 0);

	InitTimer();
}

void stop_app()
{
	// deinitialize
	DeInitTimer();

	delete pBoards[0];
	delete pBoards[1];
}


static void CALLBACK TimerProc(UINT wTimerID, UINT msg, DWORD dwUser, DWORD dw1, DWORD dw2) 
{
	SetEvent(doFrame);
}


void InitTimer()
{
	dword	msInterval = 1000 / TARGET_FPS;
	dword	wTimerRes = 0;

	TimerID = timeSetEvent(msInterval,wTimerRes,TimerProc,0,TIME_PERIODIC );
}

void DeInitTimer()
{
	if (TimerID) {
		timeKillEvent(TimerID);
		TimerID = 0;
	}
} 


void __cdecl life_app(void *pVar)
{
	while (WaitForSingleObject(doFrame, INFINITE) == WAIT_OBJECT_0) {
		life_frame();
	}
}


void life_frame()
{
	byte	*pBoard, *pNewBoard;
	dword	 u, v;


	// has a minute passed ?
	if (frameNum == 60*TARGET_FPS) {
		// a minute has passed, reset
		memset(pBoards[0], 0, LIFE_SIZE);
		memset(pBoards[1], 0, LIFE_SIZE);

		for (dword u=0; u<LIFE_WIDTH-1; u++) {
			for (dword v=0; v<LIFE_HEIGHT-1; v++) {
				if (rand() > 26384) {
					pBoards[0][u+v*LIFE_WIDTH] = 1;
				}
			}
		}

		frameNum = 0;
		nCurBoard = 0;
	}


	// set boards
	pBoard = pBoards[nCurBoard];
	pNewBoard = pBoards[!nCurBoard];

	// propagate life
	for (u=0; u<LIFE_WIDTH; u++) {
		for (v=0; v<LIFE_HEIGHT; v++) {
			// count neighbours
			dword	 ofs, count;

			ofs = u+v*LIFE_WIDTH;

			if (u == 0 || u == LIFE_WIDTH-1 || v == 0 || v == LIFE_HEIGHT-1) {
				count =  pBoard[(LIFE_SIZE+ofs-LIFE_WIDTH-1)%LIFE_SIZE];
				count += pBoard[(LIFE_SIZE+ofs-LIFE_WIDTH+0)%LIFE_SIZE];
				count += pBoard[(LIFE_SIZE+ofs-LIFE_WIDTH+1)%LIFE_SIZE];

				count += pBoard[(LIFE_SIZE+ofs-1)%LIFE_SIZE];
				count += pBoard[(ofs+1)%LIFE_SIZE];

				count += pBoard[(ofs+LIFE_WIDTH-1)%LIFE_SIZE];
				count += pBoard[(ofs+LIFE_WIDTH+0)%LIFE_SIZE];
				count += pBoard[(ofs+LIFE_WIDTH+1)%LIFE_SIZE];
			} else {
				count =  pBoard[ofs-LIFE_WIDTH-1];
				count += pBoard[ofs-LIFE_WIDTH+0];
				count += pBoard[ofs-LIFE_WIDTH+1];

				count += pBoard[ofs-1];
				count += pBoard[ofs+1];

				count += pBoard[ofs+LIFE_WIDTH-1];
				count += pBoard[ofs+LIFE_WIDTH+0];
				count += pBoard[ofs+LIFE_WIDTH+1];
			}

			// logic

			// is current cell alive ?
			if (pBoard[ofs]) {
				// yes, cell is alive
				
				// stay alive if you have 2 or 3 neighbours, otherwise die
				if (count == 2 || count == 3) {
					pNewBoard[ofs] = 1;
				} else {
					pNewBoard[ofs] = 0;
				}
			} else {
				// cell is currently dead

				// come to life if you have 3 neighbours
				if (count == 3) {
					pNewBoard[ofs] = 1;
				} else {
					pNewBoard[ofs] = 0;
				}
			}
		}
	}


	
	// draw

	HDC			dc;
	RECT		desktopRect;
	dword		cellSize;
	HBRUSH		hBrushes[2], oldBrush;

	GetWindowRect(hWnd, &desktopRect);
	cellSize = (desktopRect.right - desktopRect.left) / LIFE_WIDTH;

	dc = GetDC(hWnd);

	// create brushes
	hBrushes[0] = CreateSolidBrush(RGB(0,0,0));
	hBrushes[1] = CreateSolidBrush(RGB(255,255,255));
	oldBrush = (HBRUSH)SelectObject(dc, hBrushes[0]);


	dword lifeOffset = 0;

	if (frameNum == 0) {
		// this is the first frame

		// erase all unlit cells
		SelectObject(dc, hBrushes[0]);
		Rectangle(dc, 0, 0, cellSize*LIFE_WIDTH, cellSize*LIFE_HEIGHT);

		// draw all lit cells
		SelectObject(dc, hBrushes[1]);
		for (v=0; v<LIFE_HEIGHT; v++) {
			for (u=0; u<LIFE_WIDTH; u++, lifeOffset++) {
				if (pNewBoard[lifeOffset]) {
					// draw cell
					Rectangle/*Ellipse*/(dc, u*cellSize, v*cellSize, (u+1)*cellSize, (v+1)*cellSize);
				}
			}
		}
	} else {
		// standard working
		for (v=0; v<LIFE_HEIGHT; v++) {
			for (u=0; u<LIFE_WIDTH; u++) {
				if (pBoard[lifeOffset] != pNewBoard[lifeOffset]) {
					// something has changed
					SelectObject(dc, hBrushes[pNewBoard[lifeOffset]]);
					Rectangle/*Ellipse*/(dc, u*cellSize, v*cellSize, (u+1)*cellSize, (v+1)*cellSize);
				}
				lifeOffset++;
			}
		}

		char str[128];

		sprintf(str, "Conway's game of Life, by ohad, %2d seconds to reset ", 60-(frameNum/TARGET_FPS));

		// draw some text
		TextOut(dc, 5, desktopRect.bottom-18, str, strlen(str));
	}


	// delete and release stuff
	SelectObject(dc, oldBrush);
	ReleaseDC(hWnd, dc);

	DeleteObject(hBrushes[0]);
	DeleteObject(hBrushes[1]);

	// switch boards
	nCurBoard = !nCurBoard;

	// advance frame counter
	frameNum++;
}