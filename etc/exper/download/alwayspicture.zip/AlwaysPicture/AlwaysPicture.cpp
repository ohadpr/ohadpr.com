// AlwaysPicture.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#include "std.h"
#include "imgLoadBMP.h"
#include "RImage.h"

// defines
typedef unsigned char	byte;
typedef signed char		sbyte;
typedef unsigned short	word;
typedef signed short	sword;
typedef unsigned long	dword;
typedef signed long		sdword;


static HWND			 l_hWnd;
static char			 l_szWindowClass[] = "ALWAYS_THERE_CLASS";
static char			 l_szWindowTitle[] = "Always_There_App";
static BITMAPINFO	 bmpInfo;
static byte			*pImage = 0;

sdword XRES	= 116;
sdword YRES	= 208;


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

void SwitchPicture(char *pFileName)
{
	RImage image;

	imgLoadBMP(pFileName, &image);

	if (image.GetBPP() != 24) {
		MessageBox(0, "Image not 24bpp BMP", pFileName, 0);
	}

	XRES = image.GetWidth();
	YRES = image.GetHeight();

	bmpInfo.bmiHeader.biWidth = XRES;
	bmpInfo.bmiHeader.biHeight = (sword)YRES;

	if (pImage) {
		delete pImage;
	}

	pImage = new byte[XRES*YRES*4];
	byte *pTmp = (byte*)image.GetData();
	
	for (int i=0; i<XRES*YRES; i++) {
		pImage[i*4+0] = pTmp[i*3+2];
		pImage[i*4+1] = pTmp[i*3+1];
		pImage[i*4+2] = pTmp[i*3+0];
		pImage[i*4+3] = 0;
	}

	MoveWindow(l_hWnd, 200, 200, XRES, YRES, true);
}


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	XRES = 100;
	YRES = 100;

	pImage = new byte[XRES*YRES*4];
	for (int i=0; i<XRES*YRES*4; i++) {
		pImage[i] = 255;
	}

	bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmpInfo.bmiHeader.biWidth = XRES;
	bmpInfo.bmiHeader.biHeight = -(sword)YRES;
	bmpInfo.bmiHeader.biPlanes = 1;
	bmpInfo.bmiHeader.biBitCount = 32;
	bmpInfo.bmiHeader.biCompression = BI_RGB;
	bmpInfo.bmiHeader.biSizeImage = 0;
	bmpInfo.bmiHeader.biXPelsPerMeter = 1;
	bmpInfo.bmiHeader.biYPelsPerMeter = 1;
	bmpInfo.bmiHeader.biClrUsed = 0;
	bmpInfo.bmiHeader.biClrImportant = 0;


	SwitchPicture("dog.bmp");


	// register window calss
	WNDCLASSEX wcex;

	wcex.cbSize			= sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= 0;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= 0;
	wcex.lpszClassName	= l_szWindowClass;
	wcex.hIconSm		= 0;

	RegisterClassEx(&wcex);


	l_hWnd = CreateWindowEx(WS_EX_TOOLWINDOW + WS_EX_TOPMOST, l_szWindowClass, l_szWindowTitle, WS_POPUP,
							200, 200, XRES, YRES,
							0, 0, hInstance, 0);

	if (!l_hWnd)
		return FALSE;

	ShowWindow(l_hWnd, nCmdShow);
	UpdateWindow(l_hWnd);


#define WS_EX_LAYERED	0x00080000
#define LWA_COLORKEY	0x00000001
#define LWA_ALPHA		0x00000002

	BOOL (WINAPI*MySetLayeredWindowAttributes)(HWND, COLORREF, BYTE, DWORD);

	HINSTANCE hUserDll = LoadLibrary("user32.dll");

	if (hUserDll) {
		MySetLayeredWindowAttributes = (BOOL (WINAPI*)(HWND, COLORREF, BYTE, DWORD))GetProcAddress(hUserDll, "SetLayeredWindowAttributes");
	}

	if (MySetLayeredWindowAttributes) {
		SetWindowLong(l_hWnd, GWL_EXSTYLE, GetWindowLong(l_hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
		//MySetLayeredWindowAttributes(l_hWnd, RGB(0,0,0), 192, LWA_ALPHA);
		MySetLayeredWindowAttributes(l_hWnd, RGB(255,255,255), 0, LWA_COLORKEY);
	}

	// Main message loop:
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}


	return 0;
}

void Flip()
{
	if (!pImage) {
		// go out if we don't have a picture loaded
		return;
	}

	PAINTSTRUCT	ps;

	HDC dc = BeginPaint(l_hWnd, &ps);

	int i = StretchDIBits(	dc, 
					0, 0, XRES, YRES, 
					0, 0, XRES, YRES, 
					pImage, &bmpInfo,
					DIB_RGB_COLORS,
					SRCCOPY);

	EndPaint(l_hWnd, &ps);
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	char name[128];

	GetWindowText(hwnd, name, 128);

	if (strcmp(name, l_szWindowTitle) == 0) {
		SendMessage(hwnd, WM_DESTROY, 0, 0);
	}

	return TRUE;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) 
	{
		case WM_DESTROY:
			PostQuitMessage(0);
			break;

		case WM_PAINT:
			Flip();
			return DefWindowProc(l_hWnd, message, wParam, lParam);
			break;

		case WM_LBUTTONDOWN:
			SendMessage(hWnd, WM_NCLBUTTONDOWN, HTCAPTION, lParam);
			break;

		case WM_RBUTTONDOWN:
			// do menu and stuff
			HMENU	hMenu;
			dword	menuItem;

			hMenu = LoadMenu(0, MAKEINTRESOURCE(IDR_MENU1));

			WINDOWPLACEMENT rc;
			GetWindowPlacement(hWnd, &rc);
			

			menuItem = TrackPopupMenu(	GetSubMenu(hMenu, 0), 
							TPM_LEFTALIGN + TPM_TOPALIGN + TPM_NONOTIFY + TPM_RETURNCMD,
							rc.rcNormalPosition.left+LOWORD(lParam), rc.rcNormalPosition.top+HIWORD(lParam),
							0,
							hWnd,
							0);

			if (menuItem == ID_CLOSE) {
				PostQuitMessage(0);
			} else if (menuItem == ID_CLOSE_ALL) {
				EnumWindows(EnumWindowsProc, 0);
			}

			break;

		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
	}

   return 1;
}
