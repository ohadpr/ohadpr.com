IMR MandelTest in Color

a slight modification of the old MandelbrotV (16 levels of gray).

Now supports color on the Palm-IIIc.

It uses a not-so-nice palette, i'll try to come up with something better.


ohad@visual-i.com
ohad.visual-i.com
