IMR - Life
Version 3.0
02/06/2001


This is an implementation of Conway's "Game Of Life".

This version features :

* Blazing fast life generation/animation.
* Option for a double-sized board.


contacts :

ohad.visual-i.com
ohad@visual-i.com


Version History : 

  Version 3.0 - Added screen wrapping, life patterns no wrap along screen limits, which makes things more
                      nice and correct.
                     Improved performance on color-devices.
  Version 1.0 - IMR-Life is out.
