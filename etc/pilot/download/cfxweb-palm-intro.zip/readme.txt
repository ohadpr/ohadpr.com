small palm cfxweb intro
by kombat/imr
eder@visual-i.com
ohad.visual-i.com

enjoy