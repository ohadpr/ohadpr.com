IMR-Bombers version 1.5
------------------------

Now with support for OS5 devices.

Please check 'bombers.html' for information on the game, playing instructions and registration info.

To register, please visit:
http://store.yahoo.com/pilotgearsw/ohedpres.html

To view our product page on Palmgear, go to:
http://www.palmgear.com/software/showsoftware.cfm?prodID=38015


Contact :
---------
Web-Site: http://palm.visual-i.com
Email:    bombers@visual-i.com